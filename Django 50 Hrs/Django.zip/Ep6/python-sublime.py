from tkinter import*
import sys

name = input('Enter name : ')
print("Hello "+ name)